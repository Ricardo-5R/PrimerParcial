﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrimerParcial
{
    internal class Program
    {
        static void Main(string[] args)
        {
            new PrimerParcial.Menu().menu();
        }
    }
}
