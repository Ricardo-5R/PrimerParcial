﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENTITY
{
    public static class NomArchivo
    {
        public const string NombreHuespec = "huespec.txt";
        public const string NombreReserva = "reserva.txt";
  
    }
}
